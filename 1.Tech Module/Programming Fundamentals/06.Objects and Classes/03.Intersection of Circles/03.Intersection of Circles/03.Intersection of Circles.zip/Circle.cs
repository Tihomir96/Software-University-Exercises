﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Intersection_of_Circles
{
    public class Circle
    {
        public Point Center { get; set; }
        public int Radius { get; set; }




    }
}
