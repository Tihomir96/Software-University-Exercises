﻿
using System.ComponentModel;

namespace _5.Mordor_s_cruelty_plan.Models.Foods
{
   public class Apple:Food
   {
       private const int HapinessPoints = 1;
        public Apple() : base(HapinessPoints)
        {
        }
    }
}
