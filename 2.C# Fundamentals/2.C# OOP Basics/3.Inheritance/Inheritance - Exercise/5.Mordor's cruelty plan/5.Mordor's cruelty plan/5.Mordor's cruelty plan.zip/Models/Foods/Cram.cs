﻿
namespace _5.Mordor_s_cruelty_plan.Models.Foods
{
    public class Cram:Food
    {
        private const int HapinessPoints = 2;
        public Cram() : base(HapinessPoints)
        {
        }
    }
}
