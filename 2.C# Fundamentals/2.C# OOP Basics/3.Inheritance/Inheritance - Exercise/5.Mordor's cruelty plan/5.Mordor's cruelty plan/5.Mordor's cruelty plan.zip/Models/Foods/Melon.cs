﻿namespace _5.Mordor_s_cruelty_plan.Models.Foods
{
    public class Melon:Food
    {
        private const int HapinessPoints = 1;
        public Melon() : base(HapinessPoints)
        {
        }
    }
}
