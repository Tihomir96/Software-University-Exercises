﻿
namespace _5.Mordor_s_cruelty_plan.Models.Foods
{
    public class Mushrooms : Food
    {
        private const int HapinessPoints = -10;
        public Mushrooms() : base(HapinessPoints)
        {
        }
    }
}
