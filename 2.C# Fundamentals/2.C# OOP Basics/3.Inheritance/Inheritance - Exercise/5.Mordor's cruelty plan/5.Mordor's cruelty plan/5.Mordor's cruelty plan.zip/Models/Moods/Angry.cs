﻿
namespace _5.Mordor_s_cruelty_plan.Models.Moods
{
    public class Angry : Mood
    {
        private const string MoodName = "Angry";
        public Angry() : base(MoodName)
        {
        }
    }
}
