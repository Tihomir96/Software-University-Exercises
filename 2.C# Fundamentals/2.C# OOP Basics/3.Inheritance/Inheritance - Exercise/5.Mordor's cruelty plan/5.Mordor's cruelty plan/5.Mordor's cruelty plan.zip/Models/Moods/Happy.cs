﻿
namespace _5.Mordor_s_cruelty_plan.Models.Moods
{
    public class Happy : Mood
    {
        private const string MoodName = "Happy";
        public Happy() : base(MoodName)
        {
        }
    }
}
