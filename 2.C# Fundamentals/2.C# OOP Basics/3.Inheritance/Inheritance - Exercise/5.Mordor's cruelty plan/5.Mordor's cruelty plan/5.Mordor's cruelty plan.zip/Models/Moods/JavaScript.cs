﻿
namespace _5.Mordor_s_cruelty_plan.Models.Moods
{
    public class JavaScript : Mood
    {
        private const string MoodName = "JavaScript";
        public JavaScript() : base(MoodName)
        {
        }
    }
}
