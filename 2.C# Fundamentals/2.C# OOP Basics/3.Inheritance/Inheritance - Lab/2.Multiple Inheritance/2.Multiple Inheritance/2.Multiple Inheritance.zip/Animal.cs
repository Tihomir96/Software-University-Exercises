﻿using System;

class Animal
{
    public void Eating()
    {
        Console.WriteLine("eating...");
    }
}

