﻿using System;

class Dog:Animal
{
    public void Bark()
    {
        Console.WriteLine("barking...");
    }
}


