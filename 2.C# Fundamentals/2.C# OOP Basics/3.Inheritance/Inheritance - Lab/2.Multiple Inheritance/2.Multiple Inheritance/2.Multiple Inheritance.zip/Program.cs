﻿class Program
{
    static void Main()
    {
        Puppy pup = new Puppy();
        pup.Eating();
        pup.Bark();
        pup.Weep();       
    }
}

