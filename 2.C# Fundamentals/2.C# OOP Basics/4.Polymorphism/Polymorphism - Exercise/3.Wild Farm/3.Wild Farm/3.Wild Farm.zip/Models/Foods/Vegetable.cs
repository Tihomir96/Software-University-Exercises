﻿
namespace _3.Wild_Farm.Models.Foods
{
    class Vegetable:Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
