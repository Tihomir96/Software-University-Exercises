﻿
public class StartUp
{
    public static void Main()
    {
        var run = new Engine();
        run.Run();
    }
}





