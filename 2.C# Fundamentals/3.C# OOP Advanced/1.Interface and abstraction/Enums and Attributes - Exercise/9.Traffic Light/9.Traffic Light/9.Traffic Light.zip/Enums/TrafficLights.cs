﻿namespace _9.Traffic_Light.Enums
{
    public enum TrafficLights
    {
        Red,
        Green,
        Yellow
    }
}
