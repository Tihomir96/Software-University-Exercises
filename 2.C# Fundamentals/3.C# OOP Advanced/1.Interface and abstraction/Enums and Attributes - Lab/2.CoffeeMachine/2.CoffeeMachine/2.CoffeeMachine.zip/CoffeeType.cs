﻿public enum CoffeeType
{
    Espresso,Latte,Irish
}