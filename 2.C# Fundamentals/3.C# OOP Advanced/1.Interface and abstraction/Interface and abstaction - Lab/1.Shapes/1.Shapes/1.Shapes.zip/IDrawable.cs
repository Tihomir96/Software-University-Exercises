﻿

    interface IDrawable
    {
        void Draw();
    }

