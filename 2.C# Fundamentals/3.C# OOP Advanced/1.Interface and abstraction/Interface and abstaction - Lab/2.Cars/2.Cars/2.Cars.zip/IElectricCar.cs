﻿interface IElectricCar:ICar
{
    int Battery { get; }
}



