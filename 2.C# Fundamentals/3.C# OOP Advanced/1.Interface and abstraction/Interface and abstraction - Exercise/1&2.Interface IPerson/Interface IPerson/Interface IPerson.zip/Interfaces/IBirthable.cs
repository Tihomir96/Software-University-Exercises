﻿namespace Interface_IPerson.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
