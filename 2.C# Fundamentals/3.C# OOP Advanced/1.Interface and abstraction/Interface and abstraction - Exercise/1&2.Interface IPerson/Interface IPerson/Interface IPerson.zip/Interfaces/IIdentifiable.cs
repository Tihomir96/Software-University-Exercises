﻿namespace Interface_IPerson
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
