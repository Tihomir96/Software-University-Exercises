﻿namespace _3.Ferrari
{
    interface ICar
    {
        string Driver { get; }
        string Brakes();
        string Gas();
    }
}
