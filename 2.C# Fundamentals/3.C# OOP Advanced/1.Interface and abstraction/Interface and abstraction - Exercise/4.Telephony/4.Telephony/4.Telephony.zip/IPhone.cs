﻿namespace _4.Telephony
{
    public interface IPhone
    {
        string Calling(string phone);
        string Browsing(string url);
    }
}
