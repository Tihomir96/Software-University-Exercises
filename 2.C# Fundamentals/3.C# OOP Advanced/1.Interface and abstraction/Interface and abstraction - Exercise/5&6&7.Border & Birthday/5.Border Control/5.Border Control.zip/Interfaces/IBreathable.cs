﻿namespace _5.Border_Control
{
    public interface IBreathable
    {
        string Name { get; }
        string BirthDate { get; }
    }
}
