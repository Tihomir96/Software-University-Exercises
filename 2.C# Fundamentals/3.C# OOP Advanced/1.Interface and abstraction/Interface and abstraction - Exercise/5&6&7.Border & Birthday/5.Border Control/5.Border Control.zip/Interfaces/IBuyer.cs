﻿using System;

namespace _5.Border_Control.Interfaces
{
    public interface IBuyer
    {
        void BuyFood();
        int Food { get; }
        
    }
}
