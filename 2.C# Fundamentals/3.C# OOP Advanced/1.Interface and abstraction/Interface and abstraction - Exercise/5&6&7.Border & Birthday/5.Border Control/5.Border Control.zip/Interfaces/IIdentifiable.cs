﻿namespace _5.Border_Control
{
    public interface IIdentifiable
    {
        string id { get; }
    }
}
