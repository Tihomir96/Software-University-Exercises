﻿using System;
using System.Collections.Generic;
using System.Linq;
using _5.Border_Control.Core;

namespace _5.Border_Control
{
    public class Program
    {
        public static void Main()
        {
           var engine = new Engine();
            engine.FoodShortage();
        }
    }
}
