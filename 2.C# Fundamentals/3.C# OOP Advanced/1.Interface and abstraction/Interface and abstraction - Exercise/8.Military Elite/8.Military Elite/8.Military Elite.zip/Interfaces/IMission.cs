﻿namespace _8.Military_Elite.Interfaces
{
    public interface IMission
    {
        string Name { get; }
        string State { get; }
    }
}
