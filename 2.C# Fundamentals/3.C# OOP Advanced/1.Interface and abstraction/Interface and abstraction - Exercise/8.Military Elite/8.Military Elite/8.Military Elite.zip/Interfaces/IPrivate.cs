﻿namespace _8.Military_Elite
{
    public interface IPrivate:ISoldier
    {
        double Salary{ get; }

    }
}
