﻿namespace _8.Military_Elite.Interfaces
{
    public interface IRepair
    {
        string Name { get; }
        int Hours { get; }
    }
}
