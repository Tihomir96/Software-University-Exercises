﻿namespace _8.Military_Elite
{
    public interface ISoldier
    {
        string Id { get; }
        string FirstName { get; }
        string LastName { get; }

    }
}
