﻿namespace _8.Military_Elite
{
    public interface ISpecialisedSoldier:IPrivate
    {
        string Corps { get; }
    }   
}
    