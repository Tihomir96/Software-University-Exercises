﻿namespace _8.Military_Elite.Interfaces
{
    public interface ISpy:ISoldier
    {
        int CodeNumber { get; }
    }
}
