﻿namespace _1.Card_Suit
{
    [Type("Enumeration", "Suit", "Provides suit constants for a Card class.")]
    public enum CardSuits
    {
        Clubs,
        Diamonds=13,
        Hearts =26,
        Spades =39   
    }
}
