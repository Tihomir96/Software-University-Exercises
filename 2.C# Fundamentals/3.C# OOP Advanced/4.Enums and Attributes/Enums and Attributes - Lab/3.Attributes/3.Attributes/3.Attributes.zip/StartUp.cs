﻿[SoftUni("Yaba-Daba")]
public class StartUp
{
    [SoftUni("Duu")]
    public static void Main()
    {
        var tracker = new Tracker();
        tracker.PrintMethodsByAuthor();
    }
}

