﻿public class AutomaticMachine : Ammunition
{
    public const double AmWeight = 6.3;

    public AutomaticMachine(string name,int number)
        : base(name,AmWeight,number)
    {
       
    }
}