﻿    public class Gun:Ammunition
    {
        public const double GunWeight = 1.4;

        public Gun(string name,int number)
            : base(name,GunWeight,number)
        {
            
    }
}
