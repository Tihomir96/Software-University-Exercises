﻿    public class MachineGun:Ammunition
    {
        public const double MachineWeight = 10.6;

        public MachineGun(string name,int number)
            : base(name,MachineWeight,number)
        {
        
    }
}
