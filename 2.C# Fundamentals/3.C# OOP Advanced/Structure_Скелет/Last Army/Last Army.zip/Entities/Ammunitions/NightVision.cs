﻿
    public class NightVision:Ammunition
    {
        public const double NvWeight = 0.8;

        public NightVision(string name,int number)
            : base (name,NvWeight,number)
        {
            
        }
}
