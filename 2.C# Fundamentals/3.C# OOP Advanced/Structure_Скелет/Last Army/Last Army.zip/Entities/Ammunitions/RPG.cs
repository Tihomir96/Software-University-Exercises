﻿
    public class RPG:Ammunition
    {
        public const double RpgWeight = 17.1;

        public RPG(string name,int number)
            : base(name,RpgWeight,number)
        {
    }
}