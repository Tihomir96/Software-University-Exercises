﻿
    public class Shield:Ammunition
    {
        public const double ShieldWeight = 3.7;

        public Shield(string name,int number)
            : base(name,ShieldWeight,number)
        {
           
    }
}
