﻿public interface IWareHouse
{
    void EquipArmy(IArmy army);
}
