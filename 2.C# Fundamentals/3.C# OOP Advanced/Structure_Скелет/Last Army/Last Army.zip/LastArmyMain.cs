﻿    public class LastArmyMain
    {
        public static void Main()
        {
           IEngine engine = new Engine();
           engine.Run();
        }
    }
