﻿using System;


    public class Person
    {
        public string Name { get; set; }
        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

    }
