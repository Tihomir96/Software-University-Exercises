﻿namespace Instagraph.DataProcessor.ExportDto
{
    public class UncommentedPostDto
    {
        public int Id { get; set; }/*postId*/
        public string Picture { get; set; }/*picturePath*/
        public string User { get; set; }/*username*/
    }
}
