﻿namespace Instagraph.DataProcessor.ExportDto
{
    public class UserTopPostDto
    {
        public string Username { get; set; }
        public int MostComments { get; set; }
    }
}
