﻿using Instagraph.Models;

namespace Instagraph.DataProcessor.ImportDto
{
    public class PostDto
    {
        public string Caption { get; set; }
        public string User { get; set; }/*User's username*/
        public string Picture { get; set; }/*PicturePath*/
    }
}
