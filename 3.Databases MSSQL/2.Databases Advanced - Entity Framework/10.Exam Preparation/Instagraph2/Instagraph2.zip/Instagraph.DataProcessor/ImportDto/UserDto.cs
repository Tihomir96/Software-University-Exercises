﻿using Instagraph.Models;

namespace Instagraph.DataProcessor.ImportDto
{
    public  class UserDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string ProfilePicture { get; set; }
    }
}
