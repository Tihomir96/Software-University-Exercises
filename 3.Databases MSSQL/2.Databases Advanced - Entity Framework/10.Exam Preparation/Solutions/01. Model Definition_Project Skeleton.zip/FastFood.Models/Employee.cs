namespace FastFood.Models
{
	public class Employee
	{
	}
}