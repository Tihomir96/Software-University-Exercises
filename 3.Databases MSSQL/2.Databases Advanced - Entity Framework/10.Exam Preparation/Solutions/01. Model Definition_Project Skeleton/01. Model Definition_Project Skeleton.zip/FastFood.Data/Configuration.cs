namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-4T8RDND\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}