﻿
namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        //KonfitaBace
        internal const string ConnectionString =
            "Server=.;Database=Sale;Integrated Security=True;";
    }
}
