﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        internal const string ConnectionString =
            "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
    }
}
