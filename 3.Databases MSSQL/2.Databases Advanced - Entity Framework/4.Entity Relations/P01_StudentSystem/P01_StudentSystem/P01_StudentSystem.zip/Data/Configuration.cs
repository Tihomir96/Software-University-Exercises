﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        internal const string ConnectionString =
            "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
