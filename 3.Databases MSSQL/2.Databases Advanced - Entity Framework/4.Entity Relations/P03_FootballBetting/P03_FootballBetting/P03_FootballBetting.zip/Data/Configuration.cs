﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal class Configuration
    {
        internal const string ConnectionString =
            "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
