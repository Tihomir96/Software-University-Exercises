﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
