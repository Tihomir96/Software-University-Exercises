﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        internal static string ConnectionString => "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=PhotoShare;Integrated Security=True;";
    }
}
