﻿namespace ProductsShop.Data
{
    public class Configuration
    {
        internal const string ConnectionString =
            "Server=DESKTOP-4T8RDND\\SQLEXPRESS;Database=ProductShop;Integrated Security=True;";
    }
}
