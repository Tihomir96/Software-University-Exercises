﻿
namespace _5.Date_modifier
{
    using System;
    using System.Globalization;
    public class DateModifier
    {
        private DateTime firstDate;
        private DateTime secondDate;

        public string Datemodifier(string firstDate1, string secondDate1)
        {
            this.firstDate = DateTime.ParseExact(firstDate1, "yyyy mm dd", CultureInfo.InvariantCulture);
            this.secondDate = DateTime.ParseExact(secondDate1, "yyyy mm dd", CultureInfo.InvariantCulture);
            
            TimeSpan span = this.secondDate.Subtract(this.firstDate);
          
            return $"{Math.Abs(span.TotalDays):f0}";
        }
    }
}
