﻿using System;

namespace _5.Date_modifier
{
    class Program
    {
        static void Main()
        { 
            var dateModifier = new DateModifier();
            var date1 = Console.ReadLine();
            var date2 = Console.ReadLine();
            Console.WriteLine(dateModifier.Datemodifier(date1,date2));
        }
    }
}
