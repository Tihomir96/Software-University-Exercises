﻿
    class Program
    {
        static void Main()
        {
            var doggo = new Dog();
            doggo.Eat();
            doggo.Bark();
        }
    }

