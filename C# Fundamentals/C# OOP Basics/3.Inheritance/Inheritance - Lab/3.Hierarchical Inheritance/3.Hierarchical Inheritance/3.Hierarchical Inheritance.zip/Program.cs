﻿public class Program
{
    public static void Main()
    {
        var doggo = new Dog();
        doggo.Eat();
        doggo.Bark();

        var kitty = new Cat();
        kitty.Eat();
        kitty.Meow();
    }
}


